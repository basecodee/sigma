-- Create database
CREATE DATABASE IF NOT EXISTS payment_dashboard CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE payment_dashboard;

-- Create unit_kerja table
CREATE TABLE IF NOT EXISTS unit_kerja (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nama_lokasi VARCHAR(100) NOT NULL,
  jan BOOLEAN DEFAULT 0,
  feb BOOLEAN DEFAULT 0,
  mar BOOLEAN DEFAULT 0,
  apr BOOLEAN DEFAULT 0,
  mei BOOLEAN DEFAULT 0,
  jun BOOLEAN DEFAULT 0,
  jul BOOLEAN DEFAULT 0,
  agu BOOLEAN DEFAULT 0,
  sep BOOLEAN DEFAULT 0,
  okt BOOLEAN DEFAULT 0,
  nov BOOLEAN DEFAULT 0,
  des BOOLEAN DEFAULT 0,
  tarif INT DEFAULT 100000,
  total INT DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Create edc_cctv table
CREATE TABLE IF NOT EXISTS edc_cctv (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nama_lokasi VARCHAR(100) NOT NULL,
  jenis ENUM('EDC', 'EDC + CCTV') NOT NULL,
  tagihan INT NOT NULL,
  jan BOOLEAN DEFAULT 0,
  feb BOOLEAN DEFAULT 0,
  mar BOOLEAN DEFAULT 0,
  apr BOOLEAN DEFAULT 0,
  mei BOOLEAN DEFAULT 0,
  jun BOOLEAN DEFAULT 0,
  jul BOOLEAN DEFAULT 0,
  agu BOOLEAN DEFAULT 0,
  sep BOOLEAN DEFAULT 0,
  okt BOOLEAN DEFAULT 0,
  nov BOOLEAN DEFAULT 0,
  des BOOLEAN DEFAULT 0,
  total INT DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Create rekap_bulanan table
CREATE TABLE IF NOT EXISTS rekap_bulanan (
  id INT AUTO_INCREMENT PRIMARY KEY,
  bulan VARCHAR(20) NOT NULL,
  total_pendapatan INT DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Insert sample data for unit_kerja
INSERT INTO unit_kerja (nama_lokasi, jan, feb, mar, apr, mei, jun, jul, agu, sep, okt, nov, des, tarif, total) VALUES
('Kantor Pusat Jakarta', 1, 1, 1, 0, 0, 1, 1, 0, 1, 1, 0, 1, 100000, 800000),
('Cabang Bandung', 1, 0, 1, 1, 1, 0, 1, 1, 0, 1, 1, 0, 100000, 800000),
('Cabang Surabaya', 0, 1, 0, 1, 1, 1, 0, 1, 1, 0, 1, 1, 100000, 800000),
('Cabang Medan', 1, 1, 0, 0, 1, 0, 1, 0, 0, 1, 1, 1, 100000, 700000),
('Cabang Yogyakarta', 0, 0, 1, 1, 0, 1, 0, 1, 1, 0, 0, 1, 100000, 600000);

-- Insert sample data for edc_cctv
INSERT INTO edc_cctv (nama_lokasi, jenis, tagihan, jan, feb, mar, apr, mei, jun, jul, agu, sep, okt, nov, des, total) VALUES
('Toko Modern Plaza', 'EDC', 35000, 1, 1, 0, 1, 0, 1, 1, 0, 1, 0, 1, 1, 280000),
('Mall Central Park', 'EDC + CCTV', 135000, 0, 1, 1, 0, 1, 0, 1, 1, 0, 1, 0, 1, 810000),
('Supermarket Fresh', 'EDC', 35000, 1, 0, 1, 1, 1, 0, 0, 1, 1, 1, 0, 0, 245000),
('Hotel Grand Luxury', 'EDC + CCTV', 135000, 1, 1, 1, 0, 0, 0, 1, 1, 1, 0, 0, 1, 945000),
('Restoran Seafood Bay', 'EDC', 35000, 0, 1, 0, 0, 1, 1, 0, 0, 1, 1, 1, 0, 210000),
('Klinik Medika Utama', 'EDC + CCTV', 135000, 1, 0, 0, 1, 1, 1, 0, 0, 0, 1, 1, 1, 945000);

-- Create indexes for better performance
CREATE INDEX idx_unit_kerja_lokasi ON unit_kerja(nama_lokasi);
CREATE INDEX idx_edc_cctv_lokasi ON edc_cctv(nama_lokasi);
CREATE INDEX idx_edc_cctv_jenis ON edc_cctv(jenis);