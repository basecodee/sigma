@@ .. @@
CREATE TABLE IF NOT EXISTS unit_kerja (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nama_lokasi VARCHAR(100),
+  year INT DEFAULT 2024,
  jan BOOLEAN DEFAULT 0,
  feb BOOLEAN DEFAULT 0,
  mar BOOLEAN DEFAULT 0,
  apr BOOLEAN DEFAULT 0,
  mei BOOLEAN DEFAULT 0,
  jun BOOLEAN DEFAULT 0,
  jul BOOLEAN DEFAULT 0,
  agu BOOLEAN DEFAULT 0,
  sep BOOLEAN DEFAULT 0,
  okt BOOLEAN DEFAULT 0,
  nov BOOLEAN DEFAULT 0,
  des BOOLEAN DEFAULT 0,
  tarif INT DEFAULT 100000,
  total INT DEFAULT 0
);

-- Create edc_cctv table
CREATE TABLE IF NOT EXISTS edc_cctv (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nama_lokasi VARCHAR(100),
+  year INT DEFAULT 2024,
  jenis ENUM('EDC', 'EDC + CCTV'),
  tagihan INT,
  jan BOOLEAN DEFAULT 0,
  feb BOOLEAN DEFAULT 0,
  mar BOOLEAN DEFAULT 0,
  apr BOOLEAN DEFAULT 0,
  mei BOOLEAN DEFAULT 0,
  jun BOOLEAN DEFAULT 0,
  jul BOOLEAN DEFAULT 0,
  agu BOOLEAN DEFAULT 0,
  sep BOOLEAN DEFAULT 0,
  okt BOOLEAN DEFAULT 0,
  nov BOOLEAN DEFAULT 0,
  des BOOLEAN DEFAULT 0,
  total INT DEFAULT 0
);

-- Create rekap_bulanan table
CREATE TABLE IF NOT EXISTS rekap_bulanan (
  id INT AUTO_INCREMENT PRIMARY KEY,
  bulan VARCHAR(20),
+  year INT DEFAULT 2024,
  total_pendapatan INT
);

-- Insert sample data for unit_kerja
-INSERT INTO unit_kerja (nama_lokasi, jan, feb, mar, apr, mei, jun, jul, agu, sep, okt, nov, des, tarif, total) VALUES
-('Kantor Pusat Jakarta', 1, 1, 1, 0, 0, 1, 1, 0, 1, 1, 0, 1, 100000, 800000),
-('Cabang Bandung', 1, 0, 1, 1, 1, 0, 1, 1, 0, 1, 1, 0, 100000, 800000),
-('Cabang Surabaya', 0, 1, 0, 1, 1, 1, 0, 1, 1, 0, 1, 1, 100000, 800000),
-('Cabang Medan', 1, 1, 0, 0, 1, 0, 1, 0, 0, 1, 1, 1, 100000, 700000),
-('Cabang Yogyakarta', 0, 0, 1, 1, 0, 1, 0, 1, 1, 0, 0, 1, 100000, 600000);
+INSERT INTO unit_kerja (nama_lokasi, year, jan, feb, mar, apr, mei, jun, jul, agu, sep, okt, nov, des, tarif, total) VALUES
+('Kantor Pusat Jakarta', 2024, 1, 1, 1, 0, 0, 1, 1, 0, 1, 1, 0, 1, 100000, 800000),
+('Cabang Bandung', 2024, 1, 0, 1, 1, 1, 0, 1, 1, 0, 1, 1, 0, 100000, 800000),
+('Cabang Surabaya', 2024, 0, 1, 0, 1, 1, 1, 0, 1, 1, 0, 1, 1, 100000, 800000),
+('Cabang Medan', 2024, 1, 1, 0, 0, 1, 0, 1, 0, 0, 1, 1, 1, 100000, 700000),
+('Cabang Yogyakarta', 2024, 0, 0, 1, 1, 0, 1, 0, 1, 1, 0, 0, 1, 100000, 600000);

-- Insert sample data for edc_cctv
-INSERT INTO edc_cctv (nama_lokasi, jenis, tagihan, jan, feb, mar, apr, mei, jun, jul, agu, sep, okt, nov, des, total) VALUES
-('Toko Modern Plaza', 'EDC', 35000, 1, 1, 0, 1, 0, 1, 1, 0, 1, 0, 1, 1, 280000),
-('Mall Central Park', 'EDC + CCTV', 135000, 0, 1, 1, 0, 1, 0, 1, 1, 0, 1, 0, 1, 810000),
-('Supermarket Fresh', 'EDC', 35000, 1, 0, 1, 1, 1, 0, 0, 1, 1, 1, 0, 0, 245000),
-('Hotel Grand Luxury', 'EDC + CCTV', 135000, 1, 1, 1, 0, 0, 0, 1, 1, 1, 0, 0, 1, 945000),
-('Restoran Seafood Bay', 'EDC', 35000, 0, 1, 0, 0, 1, 1, 0, 0, 1, 1, 1, 0, 210000),
-('Klinik Medika Utama', 'EDC + CCTV', 135000, 1, 0, 0, 1, 1, 1, 0, 0, 0, 1, 1, 1, 945000);
+INSERT INTO edc_cctv (nama_lokasi, year, jenis, tagihan, jan, feb, mar, apr, mei, jun, jul, agu, sep, okt, nov, des, total) VALUES
+('Toko Modern Plaza', 2024, 'EDC', 35000, 1, 1, 0, 1, 0, 1, 1, 0, 1, 0, 1, 1, 280000),
+('Mall Central Park', 2024, 'EDC + CCTV', 135000, 0, 1, 1, 0, 1, 0, 1, 1, 0, 1, 0, 1, 810000),
+('Supermarket Fresh', 2024, 'EDC', 35000, 1, 0, 1, 1, 1, 0, 0, 1, 1, 1, 0, 0, 245000),
+('Hotel Grand Luxury', 2024, 'EDC + CCTV', 135000, 1, 1, 1, 0, 0, 0, 1, 1, 1, 0, 0, 1, 945000),
+('Restoran Seafood Bay', 2024, 'EDC', 35000, 0, 1, 0, 0, 1, 1, 0, 0, 1, 1, 1, 0, 210000),
+('Klinik Medika Utama', 2024, 'EDC + CCTV', 135000, 1, 0, 0, 1, 1, 1, 0, 0, 0, 1, 1, 1, 945000);

+-- Add sample data for other years
+INSERT INTO unit_kerja (nama_lokasi, year, jan, feb, mar, apr, mei, jun, jul, agu, sep, okt, nov, des, tarif, total) VALUES
+('Kantor Pusat Jakarta', 2023, 1, 0, 1, 1, 0, 1, 1, 1, 1, 0, 0, 1, 100000, 800000),
+('Cabang Bandung', 2023, 0, 1, 1, 1, 1, 0, 1, 0, 0, 1, 1, 1, 100000, 800000),
+('Kantor Pusat Jakarta', 2025, 1, 1, 0, 0, 1, 1, 1, 0, 1, 1, 1, 1, 100000, 900000),
+('Cabang Bandung', 2025, 1, 1, 1, 1, 0, 0, 1, 1, 1, 1, 1, 0, 100000, 900000);
+
+INSERT INTO edc_cctv (nama_lokasi, year, jenis, tagihan, jan, feb, mar, apr, mei, jun, jul, agu, sep, okt, nov, des, total) VALUES
+('Toko Modern Plaza', 2023, 'EDC', 35000, 0, 1, 0, 1, 1, 1, 1, 0, 1, 0, 1, 0, 245000),
+('Mall Central Park', 2023, 'EDC + CCTV', 135000, 1, 1, 1, 0, 0, 0, 1, 1, 0, 1, 0, 1, 945000),
+('Toko Modern Plaza', 2025, 'EDC', 35000, 1, 1, 1, 1, 0, 1, 1, 1, 1, 0, 1, 1, 350000),
+('Mall Central Park', 2025, 'EDC + CCTV', 135000, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 0, 1, 1350000);

-- Create indexes for better performance
CREATE INDEX idx_unit_kerja_lokasi ON unit_kerja(nama_lokasi);
+CREATE INDEX idx_unit_kerja_year ON unit_kerja(year);
CREATE INDEX idx_edc_cctv_lokasi ON edc_cctv(nama_lokasi);
+CREATE INDEX idx_edc_cctv_year ON edc_cctv(year);
CREATE INDEX idx_edc_cctv_jenis ON edc_cctv(jenis);