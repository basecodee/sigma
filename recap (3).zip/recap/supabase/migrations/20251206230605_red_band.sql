/*
  # Complete Inventory Management System

  1. New Tables
    - `inventory_categories`
      - `id` (uuid, primary key)
      - `name` (text, unique)
      - `description` (text)
      - `created_at` (timestamp)
    - `inventory_items`
      - `id` (uuid, primary key)
      - `name` (text)
      - `category_id` (uuid, foreign key)
      - `sku` (text, unique)
      - `description` (text)
      - `price` (numeric)
      - `stock_quantity` (integer)
      - `min_stock_level` (integer)
      - `status` (enum)
      - `created_at` (timestamp)
    - `stock_movements`
      - `id` (uuid, primary key)
      - `item_id` (uuid, foreign key)
      - `movement_type` (enum: 'in', 'out')
      - `quantity` (integer)
      - `reference_number` (text)
      - `notes` (text)
      - `created_at` (timestamp)

  2. Security
    - Enable RLS on all tables
    - Add policies for authenticated users
*/

-- Create inventory categories table
CREATE TABLE IF NOT EXISTS inventory_categories (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text UNIQUE NOT NULL,
  description text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create inventory items table
CREATE TABLE IF NOT EXISTS inventory_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  category_id uuid REFERENCES inventory_categories(id) ON DELETE SET NULL,
  sku text UNIQUE NOT NULL,
  description text,
  price numeric(12,2) DEFAULT 0,
  stock_quantity integer DEFAULT 0,
  min_stock_level integer DEFAULT 5,
  status text CHECK (status IN ('active', 'inactive', 'discontinued')) DEFAULT 'active',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create stock movements table
CREATE TABLE IF NOT EXISTS stock_movements (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  item_id uuid REFERENCES inventory_items(id) ON DELETE CASCADE,
  movement_type text CHECK (movement_type IN ('in', 'out')) NOT NULL,
  quantity integer NOT NULL,
  reference_number text,
  notes text,
  created_by text DEFAULT 'system',
  created_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE inventory_categories ENABLE ROW LEVEL SECURITY;
ALTER TABLE inventory_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE stock_movements ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Allow all operations for authenticated users"
  ON inventory_categories
  FOR ALL
  TO authenticated
  USING (true);

CREATE POLICY "Allow all operations for authenticated users"
  ON inventory_items
  FOR ALL
  TO authenticated
  USING (true);

CREATE POLICY "Allow all operations for authenticated users"
  ON stock_movements
  FOR ALL
  TO authenticated
  USING (true);

-- Insert sample categories
INSERT INTO inventory_categories (name, description) VALUES
('EDC', 'Electronic Data Capture machines and related equipment'),
('CCTV', 'Closed Circuit Television cameras and surveillance equipment'),
('Network', 'Network equipment including routers, switches, and cables'),
('Accessories', 'Various accessories and supporting equipment'),
('Tools', 'Maintenance and installation tools');

-- Insert sample inventory items
INSERT INTO inventory_items (name, category_id, sku, description, price, stock_quantity, min_stock_level) VALUES
('EDC Machine BCA', (SELECT id FROM inventory_categories WHERE name = 'EDC'), 'EDC-BCA-001', 'BCA Electronic Data Capture machine', 2500000, 25, 5),
('EDC Machine Mandiri', (SELECT id FROM inventory_categories WHERE name = 'EDC'), 'EDC-MDR-001', 'Bank Mandiri EDC machine', 2400000, 18, 5),
('CCTV Camera Indoor 2MP', (SELECT id FROM inventory_categories WHERE name = 'CCTV'), 'CCTV-IN-2MP', '2 Megapixel indoor surveillance camera', 1200000, 15, 3),
('CCTV Camera Outdoor 4MP', (SELECT id FROM inventory_categories WHERE name = 'CCTV'), 'CCTV-OUT-4MP', '4 Megapixel outdoor surveillance camera', 1800000, 12, 3),
('Router WiFi AC1200', (SELECT id FROM inventory_categories WHERE name = 'Network'), 'NET-RTR-AC1200', 'AC1200 Dual Band WiFi Router', 350000, 8, 2),
('Switch 8 Port Gigabit', (SELECT id FROM inventory_categories WHERE name = 'Network'), 'NET-SW-8G', '8 Port Gigabit Ethernet Switch', 450000, 6, 2),
('Kabel UTP Cat6 305m', (SELECT id FROM inventory_categories WHERE name = 'Network'), 'NET-UTP-CAT6', 'Cat6 UTP Cable 305 meter roll', 1500000, 0, 1),
('Power Adapter 12V 2A', (SELECT id FROM inventory_categories WHERE name = 'Accessories'), 'ACC-PWR-12V2A', '12V 2A Power Adapter', 75000, 20, 5),
('Mounting Bracket CCTV', (SELECT id FROM inventory_categories WHERE name = 'Accessories'), 'ACC-MNT-CCTV', 'Universal CCTV mounting bracket', 125000, 30, 10);

-- Insert sample stock movements
INSERT INTO stock_movements (item_id, movement_type, quantity, reference_number, notes) VALUES
((SELECT id FROM inventory_items WHERE sku = 'EDC-BCA-001'), 'in', 30, 'PO-2024-001', 'Initial stock purchase'),
((SELECT id FROM inventory_items WHERE sku = 'EDC-BCA-001'), 'out', 5, 'INS-2024-001', 'Installation at Jakarta branch'),
((SELECT id FROM inventory_items WHERE sku = 'CCTV-IN-2MP'), 'in', 20, 'PO-2024-002', 'Monthly stock replenishment'),
((SELECT id FROM inventory_items WHERE sku = 'CCTV-IN-2MP'), 'out', 5, 'INS-2024-002', 'Installation at Bandung office'),
((SELECT id FROM inventory_items WHERE sku = 'NET-UTP-CAT6'), 'out', 1, 'INS-2024-003', 'Network installation project');

-- Create indexes for better performance
CREATE INDEX idx_inventory_items_category ON inventory_items(category_id);
CREATE INDEX idx_inventory_items_sku ON inventory_items(sku);
CREATE INDEX idx_inventory_items_status ON inventory_items(status);
CREATE INDEX idx_stock_movements_item ON stock_movements(item_id);
CREATE INDEX idx_stock_movements_type ON stock_movements(movement_type);
CREATE INDEX idx_stock_movements_date ON stock_movements(created_at);

-- Create function to update stock quantity automatically
CREATE OR REPLACE FUNCTION update_stock_quantity()
RETURNS TRIGGER AS $$
BEGIN
  IF NEW.movement_type = 'in' THEN
    UPDATE inventory_items 
    SET stock_quantity = stock_quantity + NEW.quantity,
        updated_at = now()
    WHERE id = NEW.item_id;
  ELSIF NEW.movement_type = 'out' THEN
    UPDATE inventory_items 
    SET stock_quantity = stock_quantity - NEW.quantity,
        updated_at = now()
    WHERE id = NEW.item_id;
  END IF;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create trigger to automatically update stock
CREATE TRIGGER trigger_update_stock_quantity
  AFTER INSERT ON stock_movements
  FOR EACH ROW
  EXECUTE FUNCTION update_stock_quantity();